## PROJETO FINAL UDACITY

- projeto_final.pdf:	
projeto final em pdf.

- proposta.pdf:	
proposta em pdf.

- Final_Project_Udacity_Nanodregree.ipynb:	
Códigos utilizados para realizar o projeto final.

- LotFrontage.py:	
Códigos utilizados para realizar o projeto final.

- dataset/train.csv:
Conjunto de dados do kaggle.
- dataset/test.csv:	
Conjunto de dados do kaggle.

- img/kaggle_score.png:	
Print do score do Kaggle.

- predicts_GradientBoostingRegressor.csv:
Predições geradas pelo GradientBoostingRegressor.

- predicts_SGDRegressor.csv:
Predições geradas pelo SGDRegressor.

- predicts_esemble.csv:
Predições geradas geradas pelo esemble.